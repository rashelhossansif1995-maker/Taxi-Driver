package com.taxidriver.apk;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.webkit.JavascriptInterface;
import android.graphics.pdf.PdfDocument;
import android.view.View;
import android.widget.FrameLayout;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout rootLayout;
    private File pendingPdfFile;
    private String pendingPdfFileName;
    private static final int REQUEST_CREATE_PDF = 4107;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        rootLayout = new FrameLayout(this);
        webView = new WebView(this);
        rootLayout.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(rootLayout);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new PdfBridge(), "AndroidPDF");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class PdfBridge {
        private String pendingTitle = "Taxi Driver PDF";
        private StringBuilder pendingHtml;

        @JavascriptInterface
        public synchronized boolean beginPdf(String title) {
            pendingTitle = (title == null || title.trim().isEmpty()) ? "Taxi Driver PDF" : title.trim();
            pendingHtml = new StringBuilder();
            return true;
        }

        @JavascriptInterface
        public synchronized boolean appendPdfChunk(String chunk) {
            if (pendingHtml == null) pendingHtml = new StringBuilder();
            if (chunk != null) pendingHtml.append(chunk);
            return true;
        }

        @JavascriptInterface
        public synchronized void finishPdf() {
            final String html = pendingHtml == null ? "" : pendingHtml.toString();
            final String title = pendingTitle;
            pendingHtml = null;
            runOnUiThread(() -> {
                final WebView printWebView = new WebView(MainActivity.this);
                WebSettings s = printWebView.getSettings();
                s.setJavaScriptEnabled(true);
                s.setDomStorageEnabled(true);
                s.setAllowFileAccess(true);
                s.setAllowContentAccess(true);

                printWebView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                final int initialWidth = Math.round(595f * getResources().getDisplayMetrics().density);
                FrameLayout.LayoutParams printLp = new FrameLayout.LayoutParams(initialWidth, Math.round(842f * getResources().getDisplayMetrics().density));
                printLp.leftMargin = 0;
                printLp.topMargin = 0;
                rootLayout.addView(printWebView, 0, printLp);

                printWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            view.postVisualStateCallback(System.nanoTime(), new WebView.VisualStateCallback() {
                                @Override
                                public void onComplete(long requestId) {
                                    view.postDelayed(() -> attachAndRenderPdfWebView(printWebView, title), 300);
                                }
                            });
                        } else {
                            view.postDelayed(() -> attachAndRenderPdfWebView(printWebView, title), 1000);
                        }
                    }
                });

                printWebView.loadDataWithBaseURL(
                        "file:///android_asset/",
                        html,
                        "text/html",
                        "UTF-8",
                        null
                );
            });
        }
    }

    private void attachAndRenderPdfWebView(final WebView printWebView, final String title) {
        try {
            printWebView.post(() -> generatePdfDirectly(printWebView, title));
        } catch (Exception e) {
            e.printStackTrace();
            try { printWebView.destroy(); } catch (Exception ignored) {}
            Toast.makeText(MainActivity.this, "PDF could not be created", Toast.LENGTH_LONG).show();
        }
    }

    private void generatePdfDirectly(final WebView printWebView, final String title) {
        final String safeTitle = sanitizeFileName(
                (title == null || title.trim().isEmpty()) ? "Taxi Driver PDF" : title.trim()
        );

        try {
            final float density = getResources().getDisplayMetrics().density;
            final int pageWidth = 595;
            final int pageHeight = 842;
            final int webWidth = Math.round(pageWidth * density);

            printWebView.measure(
                    View.MeasureSpec.makeMeasureSpec(webWidth, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            );
            int measuredHeight = Math.max(1, printWebView.getMeasuredHeight());
            printWebView.layout(0, 0, webWidth, measuredHeight);
            printWebView.requestLayout();

            int contentHeightCss = printWebView.getContentHeight();
            if (contentHeightCss <= 0) contentHeightCss = printWebView.getMeasuredHeight();
            int contentHeightPx = Math.max(1, Math.round(contentHeightCss * printWebView.getScale()));

            final int pageHeightPx = Math.round(pageHeight * density);
            final int pageCount = Math.max(1, (int) Math.ceil(contentHeightPx / (double) pageHeightPx));
            final File tempFile = new File(getCacheDir(), safeTitle + ".pdf");

            PdfDocument document = new PdfDocument();
            try {
                for (int pageIndex = 0; pageIndex < pageCount; pageIndex++) {
                    PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(
                            pageWidth, pageHeight, pageIndex + 1
                    ).create();
                    PdfDocument.Page page = document.startPage(pageInfo);
                    android.graphics.Canvas canvas = page.getCanvas();
                    canvas.save();
                    canvas.scale(1f / density, 1f / density);
                    canvas.translate(0, -pageIndex * pageHeightPx);
                    printWebView.draw(canvas);
                    canvas.restore();
                    document.finishPage(page);
                }

                try (FileOutputStream out = new FileOutputStream(tempFile)) {
                    document.writeTo(out);
                }
            } finally {
                document.close();
            }

            savePdfWithChooser(tempFile, safeTitle + ".pdf");
            try { rootLayout.removeView(printWebView); } catch (Exception ignored) {}
            printWebView.destroy();
        } catch (Exception e) {
            e.printStackTrace();
            runOnUiThread(() -> Toast.makeText(
                    MainActivity.this,
                    "PDF could not be created",
                    Toast.LENGTH_LONG
            ).show());
            try { printWebView.destroy(); } catch (Exception ignored) {}
        }
    }

    private void savePdfWithChooser(File source, String fileName) {
        try {
            pendingPdfFile = source;
            pendingPdfFileName = fileName;

            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/pdf");
            intent.putExtra(Intent.EXTRA_TITLE, fileName);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, REQUEST_CREATE_PDF);
        } catch (Exception e) {
            e.printStackTrace();
            saveToDownloads(source, fileName);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CREATE_PDF) return;

        File source = pendingPdfFile;
        pendingPdfFile = null;
        pendingPdfFileName = null;

        if (source == null) return;

        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            source.delete();
            Toast.makeText(this, "PDF save cancelled", Toast.LENGTH_SHORT).show();
            return;
        }

        Uri outputUri = data.getData();
        boolean success = false;
        try {
            try {
                getContentResolver().takePersistableUriPermission(
                        outputUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                );
            } catch (Exception ignored) {}

            try (InputStream in = new FileInputStream(source);
                 OutputStream out = getContentResolver().openOutputStream(outputUri, "w")) {
                if (out == null) throw new IOException("Unable to open selected file");
                copy(in, out);
                success = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            source.delete();
        }

        Toast.makeText(this, success ? "PDF saved successfully" : "PDF could not be saved", Toast.LENGTH_LONG).show();
    }

    private void saveToDownloads(File source, String fileName) {
        boolean success = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                values.put(MediaStore.Downloads.IS_PENDING, 1);

                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IOException("Unable to create Downloads file");

                try (InputStream in = new FileInputStream(source);
                     OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Unable to open Downloads output");
                    copy(in, out);
                }

                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
                success = true;
            } else {
                File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloads.exists() && !downloads.mkdirs()) throw new IOException("Cannot create Downloads");
                File target = new File(downloads, fileName);
                try (InputStream in = new FileInputStream(source);
                     OutputStream out = new FileOutputStream(target)) {
                    copy(in, out);
                }
                success = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            source.delete();
        }

        Toast.makeText(
                this,
                success ? "PDF saved to Downloads" : "PDF could not be saved",
                Toast.LENGTH_LONG
        ).show();
    }

    private void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[8192];
        int count;
        while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
        out.flush();
    }

    private void failPdf(File tempFile, WebView printWebView) {
        //noinspection ResultOfMethodCallIgnored
        tempFile.delete();
        runOnUiThread(() -> Toast.makeText(
                MainActivity.this,
                "PDF could not be created",
                Toast.LENGTH_LONG
        ).show());
        if (printWebView != null) printWebView.destroy();
    }

    private String sanitizeFileName(String name) {
        String cleaned = name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (cleaned.isEmpty()) cleaned = "Taxi Driver PDF";
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        return cleaned + "_" + stamp;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
