# Taxi Driver — GitHub AAB Build

This project wraps the supplied Taxi Driver HTML in an Android WebView.

## Build on GitHub
1. Create a GitHub repository.
2. Upload this entire project.
3. Push to the `main` branch.
4. Open **Actions** → **Build Taxi Driver AAB**.
5. Run the workflow if needed.
6. Download the `Taxi-Driver-1.0.6-AAB` artifact.

Package: `com.taxidriver.apk`
Target SDK: 36
Version: 1.0.6
