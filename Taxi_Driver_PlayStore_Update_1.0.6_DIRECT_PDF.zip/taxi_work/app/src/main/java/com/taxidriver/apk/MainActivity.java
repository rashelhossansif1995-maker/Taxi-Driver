package com.taxidriver.apk;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String PREMIUM_PRODUCT_ID = "taxi_driver_premium";
    // Google test banner ID. Replace with your real AdMob banner ID before production release.
    private static final String TEST_BANNER_AD_UNIT_ID = "ca-app-pub-2119693628616724/6269224943";

    private WebView webView;
    private AdView adView;
    private BillingClient billingClient;
    private ProductDetails premiumProductDetails;
    private boolean premiumActive = false;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        adView = new AdView(this);
        adView.setAdUnitId(TEST_BANNER_AD_UNIT_ID);
        adView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, 360));
        FrameLayout.LayoutParams adParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        adParams.gravity = android.view.Gravity.BOTTOM;
        root.addView(adView, adParams);
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBillingBridge(), "AndroidBilling");
        webView.loadUrl("file:///android_asset/index.html");

        MobileAds.initialize(this, status -> {});
        loadAdsIfNeeded();
        setupBilling();
    }

    private void setupBilling() {
        PendingPurchasesParams pendingParams = PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts()
                .build();

        billingClient = BillingClient.newBuilder(this)
                .setListener(this::onPurchasesUpdated)
                .enablePendingPurchases(pendingParams)
                .build();

        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(@NonNull BillingResult billingResult) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    queryExistingPurchase();
                    queryPremiumProduct();
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // A later user action will retry the connection.
            }
        });
    }

    private void queryPremiumProduct() {
        if (billingClient == null || !billingClient.isReady()) return;

        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(Collections.singletonList(
                        QueryProductDetailsParams.Product.newBuilder()
                                .setProductId(PREMIUM_PRODUCT_ID)
                                .setProductType(BillingClient.ProductType.INAPP)
                                .build()))
                .build();

        billingClient.queryProductDetailsAsync(params, (billingResult, productDetailsResult) -> {
            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK
                    && productDetailsResult != null
                    && productDetailsResult.getProductDetailsList() != null
                    && !productDetailsResult.getProductDetailsList().isEmpty()) {
                premiumProductDetails = productDetailsResult.getProductDetailsList().get(0);
            }
        });
    }

    private void queryExistingPurchase() {
        if (billingClient == null || !billingClient.isReady()) return;

        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.INAPP)
                .build();

        billingClient.queryPurchasesAsync(params, (billingResult, purchases) -> {
            if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
            boolean found = false;
            for (Purchase purchase : purchases) {
                if (purchase.getProducts().contains(PREMIUM_PRODUCT_ID)
                        && purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                    found = true;
                    acknowledgeIfNeeded(purchase);
                    break;
                }
            }
            setPremiumState(found);
        });
    }

    private void onPurchasesUpdated(BillingResult billingResult, List<Purchase> purchases) {
        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase purchase : purchases) {
                if (purchase.getProducts().contains(PREMIUM_PRODUCT_ID)
                        && purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                    acknowledgeIfNeeded(purchase);
                }
            }
        } else if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED) {
            Toast.makeText(this, "Premium purchase could not be completed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void acknowledgeIfNeeded(Purchase purchase) {
        if (purchase.isAcknowledged()) {
            setPremiumState(true);
            return;
        }

        AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder()
                .setPurchaseToken(purchase.getPurchaseToken())
                .build();
        billingClient.acknowledgePurchase(params, billingResult -> {
            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                setPremiumState(true);
            }
        });
    }

    private void launchPremiumPurchase() {
        if (billingClient == null) {
            setupBilling();
            Toast.makeText(this, "Connecting to Google Play...", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!billingClient.isReady()) {
            billingClient.startConnection(new BillingClientStateListener() {
                @Override public void onBillingSetupFinished(@NonNull BillingResult result) {
                    if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                        queryPremiumProduct();
                        queryExistingPurchase();
                        launchPremiumPurchase();
                    }
                }
                @Override public void onBillingServiceDisconnected() {}
            });
            return;
        }
        if (premiumActive) return;
        if (premiumProductDetails == null) {
            queryPremiumProduct();
            Toast.makeText(this, "Premium product is not available yet. Please try again.", Toast.LENGTH_SHORT).show();
            return;
        }

        List<ProductDetails.OneTimePurchaseOfferDetails> offers = premiumProductDetails.getOneTimePurchaseOfferDetailsList();
        if (offers == null || offers.isEmpty()) {
            Toast.makeText(this, "Premium product has no purchase offer.", Toast.LENGTH_SHORT).show();
            return;
        }

        BillingFlowParams.ProductDetailsParams productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(premiumProductDetails)
                .setOfferToken(offers.get(0).getOfferToken())
                .build();
        BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(productParams))
                .build();
        billingClient.launchBillingFlow(this, flowParams);
    }

    private void setPremiumState(boolean active) {
        premiumActive = active;
        runOnUiThread(() -> {
            if (active) {
                if (adView != null) adView.setVisibility(View.GONE);
            } else {
                loadAdsIfNeeded();
            }
            if (webView != null) {
                webView.evaluateJavascript("window.AndroidPremiumState && window.AndroidPremiumState(" + active + ");", null);
            }
        });
    }

    private void loadAdsIfNeeded() {
        if (premiumActive || adView == null) return;
        adView.setVisibility(View.VISIBLE);
        if (adView.getAdSize() != null) adView.loadAd(new AdRequest.Builder().build());
    }

    private class AndroidBillingBridge {
        @JavascriptInterface
        public void purchasePremium() {
            runOnUiThread(() -> launchPremiumPurchase());
        }

        @JavascriptInterface
        public boolean isPremium() {
            return premiumActive;
        }

        @JavascriptInterface
        public void restorePurchases() {
            runOnUiThread(() -> {
                queryExistingPurchase();
                Toast.makeText(MainActivity.this, "Checking Google Play purchases...", Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (billingClient != null && billingClient.isReady()) queryExistingPurchase();
        if (!premiumActive) loadAdsIfNeeded();
    }

    @Override
    protected void onDestroy() {
        if (adView != null) adView.destroy();
        if (billingClient != null) billingClient.endConnection();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
