Taxi Driver — FINAL Launcher Icon

Final design:
- Yellow rounded-square background
- Full black Taxi centered and clearly visible
- TAXI text clearly visible
- White windshield and headlights

Android standard launcher sizes are included under android_res/mipmap-*.
Use ic_launcher.png as the legacy launcher icon. For an existing Android project,
replace the app's launcher icon resources and ensure AndroidManifest.xml points
to @mipmap/ic_launcher.

Note: This package contains the final launcher-icon assets; it is not a rebuilt APK/AAB.
After replacing the icon in the Android project, build a new APK/AAB and reinstall/update it.
