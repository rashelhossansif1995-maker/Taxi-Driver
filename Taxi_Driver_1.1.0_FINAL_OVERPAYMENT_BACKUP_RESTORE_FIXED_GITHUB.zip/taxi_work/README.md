# Taxi Driver 1.1.0 — Final Overpayment + Backup/Restore Fix

Version Code: 110
Version Name: 1.1.0
Target SDK: 36

Included fixes:
- Overpayment section retained and included in backup/restore data.
- Export Backup uses the native Android save-file dialog when available.
- Restore Backup uses the Android WebView file picker.
- Added a visible Choose File button for Restore Backup.
- Removed all literal "Financial Loan" wording from the HTML UI/report layer.
- Native MainActivity backup bridge remains enabled.
