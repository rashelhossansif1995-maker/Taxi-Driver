TAXI DRIVER 1.1.2 — MERGED SOURCE PROJECT (NOT A BUILT AAB)

This project starts from the supplied Taxi Driver 1.1.1 source ZIP and preserves its Android project, resources, and main HTML features. It adds a custom dark premium-style prompt for editing Overpayment/Admin history amounts and choosing a country, and sets versionName 1.1.2 / versionCode 112. compileSdk and targetSdk remain 36. applicationId remains com.taxidriver.apk.

IMPORTANT:
- This is source code only. No APK/AAB has been built or tested here.
- Keep the existing Play Console app identity. Before uploading an update, confirm the package ID matches the existing Closed testing app.
- The AAB must be signed with the correct upload key or signed through the existing Play App Signing setup. A previous AAB does not contain the private upload key.
- Do not upload until a build succeeds and you test the APK.
