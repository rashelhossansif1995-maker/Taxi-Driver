# Taxi Driver Android AAB Project

## Native Premium / Ads configuration
- Package: `com.taxidriver.apk`
- Target API: 36
- Version: 1.0.6 (versionCode 6)
- Google Play one-time product ID: `taxi_driver_premium`
- Google Play Billing Library: 9.1.0
- Google Mobile Ads SDK: 25.5.0
- Current AdMob App ID and Banner ID are Google's official test IDs for build/testing.

### Before production release
1. In Google Play Console, create an **in-app product (one-time product)** with product ID exactly `taxi_driver_premium`.
2. Replace the test AdMob App ID in `app/src/main/AndroidManifest.xml` with your real AdMob App ID.
3. Replace the test banner ad unit ID in `app/src/main/java/com/taxidriver/apk/MainActivity.java` with your real banner ad unit ID.
4. Upload the AAB through a Play testing track first and test purchase, acknowledgement, restore, and Premium ad removal with a license/test account.

Premium state is re-queried from Google Play on startup/resume and is exposed to the WebView as `AndroidBilling.isPremium()` / `window.AndroidPremiumState(...)`. Free users get the banner; Premium users hide it.
