package com.taxidriver.apk;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.graphics.pdf.PdfDocument;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new PdfBridge(), "AndroidPDF");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class PdfBridge {
        @JavascriptInterface
        public void savePdf(final String html, final String title) {
            runOnUiThread(() -> {
                final WebView printWebView = new WebView(MainActivity.this);
                WebSettings s = printWebView.getSettings();
                s.setJavaScriptEnabled(true);
                s.setDomStorageEnabled(true);
                s.setAllowFileAccess(true);
                s.setAllowContentAccess(true);

                printWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        view.postDelayed(() -> generatePdfDirectly(printWebView, title), 500);
                    }
                });

                printWebView.loadDataWithBaseURL(
                        "file:///android_asset/",
                        html,
                        "text/html",
                        "UTF-8",
                        null
                );
            });
        }
    }

    private void generatePdfDirectly(final WebView printWebView, final String title) {
        final String safeTitle = sanitizeFileName(
                (title == null || title.trim().isEmpty()) ? "Taxi Driver PDF" : title.trim()
        );

        try {
            final float density = getResources().getDisplayMetrics().density;
            final int pageWidth = 595;
            final int pageHeight = 842;
            final int webWidth = Math.round(pageWidth * density);

            printWebView.measure(
                    View.MeasureSpec.makeMeasureSpec(webWidth, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            );
            printWebView.layout(0, 0, webWidth, printWebView.getMeasuredHeight());

            int contentHeightCss = printWebView.getContentHeight();
            if (contentHeightCss <= 0) contentHeightCss = printWebView.getMeasuredHeight();
            int contentHeightPx = Math.max(1, Math.round(contentHeightCss * printWebView.getScale()));

            final int pageHeightPx = Math.round(pageHeight * density);
            final int pageCount = Math.max(1, (int) Math.ceil(contentHeightPx / (double) pageHeightPx));
            final File tempFile = new File(getCacheDir(), safeTitle + ".pdf");

            PdfDocument document = new PdfDocument();
            try {
                for (int pageIndex = 0; pageIndex < pageCount; pageIndex++) {
                    PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(
                            pageWidth, pageHeight, pageIndex + 1
                    ).create();
                    PdfDocument.Page page = document.startPage(pageInfo);
                    android.graphics.Canvas canvas = page.getCanvas();
                    canvas.save();
                    canvas.scale(1f / density, 1f / density);
                    canvas.translate(0, -pageIndex * pageHeightPx);
                    printWebView.draw(canvas);
                    canvas.restore();
                    document.finishPage(page);
                }

                try (FileOutputStream out = new FileOutputStream(tempFile)) {
                    document.writeTo(out);
                }
            } finally {
                document.close();
            }

            saveToDownloads(tempFile, safeTitle + ".pdf");
            printWebView.destroy();
        } catch (Exception e) {
            e.printStackTrace();
            runOnUiThread(() -> Toast.makeText(
                    MainActivity.this,
                    "PDF could not be created",
                    Toast.LENGTH_LONG
            ).show());
            try { printWebView.destroy(); } catch (Exception ignored) {}
        }
    }

    private void saveToDownloads(File source, String fileName) {
        boolean success = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                values.put(MediaStore.Downloads.IS_PENDING, 1);

                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IOException("Unable to create Downloads file");

                try (InputStream in = new FileInputStream(source);
                     OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Unable to open Downloads output");
                    copy(in, out);
                }

                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
                success = true;
            } else {
                File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloads.exists() && !downloads.mkdirs()) throw new IOException("Cannot create Downloads");
                File target = new File(downloads, fileName);
                try (InputStream in = new FileInputStream(source);
                     OutputStream out = new FileOutputStream(target)) {
                    copy(in, out);
                }
                success = true;
            }
        } catch (Exception e) {
            success = false;
        } finally {
            //noinspection ResultOfMethodCallIgnored
            source.delete();
        }

        final boolean saved = success;
        runOnUiThread(() -> Toast.makeText(
                MainActivity.this,
                saved ? "PDF saved to Downloads" : "PDF could not be saved",
                Toast.LENGTH_LONG
        ).show());
    }

    private void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[8192];
        int count;
        while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
        out.flush();
    }

    private void failPdf(File tempFile, WebView printWebView) {
        //noinspection ResultOfMethodCallIgnored
        tempFile.delete();
        runOnUiThread(() -> Toast.makeText(
                MainActivity.this,
                "PDF could not be created",
                Toast.LENGTH_LONG
        ).show());
        if (printWebView != null) printWebView.destroy();
    }

    private String sanitizeFileName(String name) {
        String cleaned = name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (cleaned.isEmpty()) cleaned = "Taxi Driver PDF";
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        return cleaned + "_" + stamp;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
