package com.taxidriver.apk;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    // Google Play product IDs configured in Play Console.
    private static final String LIFETIME_PRODUCT_ID = "taxi_driver_premium";
    private static final String MONTHLY_PRODUCT_ID = "taxi_driver_premium_monthly";
    private static final String YEARLY_PRODUCT_ID = "taxi_driver_premium_yearly";

    // Google test banner ID already present in the project.
    private static final String TEST_BANNER_AD_UNIT_ID = "ca-app-pub-2119693628616724/6269224943";

    private WebView webView;
    private AdView adView;
    private BillingClient billingClient;

    private ProductDetails lifetimeProductDetails;
    private ProductDetails monthlyProductDetails;
    private ProductDetails yearlyProductDetails;
    private boolean premiumActive = false;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        adView = new AdView(this);
        adView.setAdUnitId(TEST_BANNER_AD_UNIT_ID);
        adView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, 360));
        FrameLayout.LayoutParams adParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        adParams.gravity = android.view.Gravity.BOTTOM;
        root.addView(adView, adParams);
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBillingBridge(), "AndroidBilling");
        webView.loadUrl("file:///android_asset/index.html");

        MobileAds.initialize(this, status -> {});
        loadAdsIfNeeded();
        setupBilling();
    }

    private void setupBilling() {
        PendingPurchasesParams pendingParams = PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts()
                .build();

        billingClient = BillingClient.newBuilder(this)
                .setListener(this::onPurchasesUpdated)
                .enablePendingPurchases(pendingParams)
                .build();

        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(@NonNull BillingResult billingResult) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    queryExistingPurchases();
                    queryAllPremiumProducts();
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // A later user action will retry the connection.
            }
        });
    }

    private void queryAllPremiumProducts() {
        if (billingClient == null || !billingClient.isReady()) return;

        QueryProductDetailsParams inAppParams = QueryProductDetailsParams.newBuilder()
                .setProductList(Collections.singletonList(
                        QueryProductDetailsParams.Product.newBuilder()
                                .setProductId(LIFETIME_PRODUCT_ID)
                                .setProductType(BillingClient.ProductType.INAPP)
                                .build()))
                .build();

        billingClient.queryProductDetailsAsync(inAppParams, (result, detailsResult) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK
                    && detailsResult != null
                    && detailsResult.getProductDetailsList() != null
                    && !detailsResult.getProductDetailsList().isEmpty()) {
                lifetimeProductDetails = detailsResult.getProductDetailsList().get(0);
            }
        });

        List<QueryProductDetailsParams.Product> subscriptionProducts = new ArrayList<>();
        subscriptionProducts.add(QueryProductDetailsParams.Product.newBuilder()
                .setProductId(MONTHLY_PRODUCT_ID)
                .setProductType(BillingClient.ProductType.SUBS)
                .build());
        subscriptionProducts.add(QueryProductDetailsParams.Product.newBuilder()
                .setProductId(YEARLY_PRODUCT_ID)
                .setProductType(BillingClient.ProductType.SUBS)
                .build());

        QueryProductDetailsParams subsParams = QueryProductDetailsParams.newBuilder()
                .setProductList(subscriptionProducts)
                .build();

        billingClient.queryProductDetailsAsync(subsParams, (result, detailsResult) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK
                    || detailsResult == null
                    || detailsResult.getProductDetailsList() == null) return;

            for (ProductDetails details : detailsResult.getProductDetailsList()) {
                if (MONTHLY_PRODUCT_ID.equals(details.getProductId())) {
                    monthlyProductDetails = details;
                } else if (YEARLY_PRODUCT_ID.equals(details.getProductId())) {
                    yearlyProductDetails = details;
                }
            }
        });
    }

    private void queryExistingPurchases() {
        if (billingClient == null || !billingClient.isReady()) return;

        QueryPurchasesParams inAppParams = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.INAPP)
                .build();

        billingClient.queryPurchasesAsync(inAppParams, (billingResult, purchases) -> {
            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                for (Purchase purchase : purchases) {
                    if (purchase.getProducts().contains(LIFETIME_PRODUCT_ID)
                            && purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                        acknowledgeIfNeeded(purchase);
                        return;
                    }
                }
            }
            querySubscriptionPurchases();
        });
    }

    private void querySubscriptionPurchases() {
        if (billingClient == null || !billingClient.isReady()) return;

        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.SUBS)
                .build();

        billingClient.queryPurchasesAsync(params, (billingResult, purchases) -> {
            if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                setPremiumState(false);
                return;
            }

            boolean found = false;
            for (Purchase purchase : purchases) {
                boolean isOurSubscription =
                        purchase.getProducts().contains(MONTHLY_PRODUCT_ID)
                                || purchase.getProducts().contains(YEARLY_PRODUCT_ID);

                if (isOurSubscription
                        && purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                    found = true;
                    acknowledgeIfNeeded(purchase);
                    break;
                }
            }

            if (!found) setPremiumState(false);
        });
    }

    private void onPurchasesUpdated(BillingResult billingResult, List<Purchase> purchases) {
        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK
                && purchases != null) {
            for (Purchase purchase : purchases) {
                boolean isOurProduct =
                        purchase.getProducts().contains(LIFETIME_PRODUCT_ID)
                                || purchase.getProducts().contains(MONTHLY_PRODUCT_ID)
                                || purchase.getProducts().contains(YEARLY_PRODUCT_ID);

                if (isOurProduct
                        && purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                    acknowledgeIfNeeded(purchase);
                }
            }
        } else if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED) {
            Toast.makeText(this, "Premium purchase could not be completed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void acknowledgeIfNeeded(Purchase purchase) {
        if (purchase.isAcknowledged()) {
            setPremiumState(true);
            return;
        }

        AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder()
                .setPurchaseToken(purchase.getPurchaseToken())
                .build();

        billingClient.acknowledgePurchase(params, billingResult -> {
            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                setPremiumState(true);
            }
        });
    }

    private void launchPremiumPurchase() {
        if (billingClient == null) {
            setupBilling();
            Toast.makeText(this, "Connecting to Google Play...", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!billingClient.isReady()) {
            billingClient.startConnection(new BillingClientStateListener() {
                @Override
                public void onBillingSetupFinished(@NonNull BillingResult result) {
                    if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                        queryAllPremiumProducts();
                        queryExistingPurchases();
                        showPremiumPlans();
                    }
                }

                @Override
                public void onBillingServiceDisconnected() {}
            });
            return;
        }

        if (premiumActive) return;

        queryAllPremiumProducts();
        showPremiumPlans();
    }

    private void showPremiumPlans() {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;

            String lifetime = getOneTimePrice(lifetimeProductDetails);
            String monthly = getSubscriptionPrice(monthlyProductDetails);
            String yearly = getSubscriptionPrice(yearlyProductDetails);

            if (lifetime == null && monthly == null && yearly == null) {
                Toast.makeText(this,
                        "Premium plans are not available yet. Please try again.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            ArrayList<String> labels = new ArrayList<>();
            ArrayList<Integer> choices = new ArrayList<>();

            if (lifetime != null) {
                labels.add("Lifetime — " + lifetime + "\nOne-time payment");
                choices.add(0);
            }
            if (monthly != null) {
                labels.add("Monthly — " + monthly + "\nAuto-renewing");
                choices.add(1);
            }
            if (yearly != null) {
                labels.add("Yearly — " + yearly + "\nAuto-renewing");
                choices.add(2);
            }

            String[] items = labels.toArray(new String[0]);
            new AlertDialog.Builder(this)
                    .setTitle("Taxi Driver Premium")
                    .setItems(items, (dialog, which) -> {
                        int choice = choices.get(which);
                        if (choice == 0) {
                            launchOneTimePurchase();
                        } else if (choice == 1) {
                            launchSubscriptionPurchase(monthlyProductDetails);
                        } else {
                            launchSubscriptionPurchase(yearlyProductDetails);
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }

    private String getOneTimePrice(ProductDetails details) {
        if (details == null || details.getOneTimePurchaseOfferDetailsList() == null
                || details.getOneTimePurchaseOfferDetailsList().isEmpty()) return null;
        return details.getOneTimePurchaseOfferDetailsList().get(0).getFormattedPrice();
    }

    private String getSubscriptionPrice(ProductDetails details) {
        if (details == null || details.getSubscriptionOfferDetails() == null
                || details.getSubscriptionOfferDetails().isEmpty()) return null;

        ProductDetails.SubscriptionOfferDetails offer =
                details.getSubscriptionOfferDetails().get(0);

        if (offer.getPricingPhases() == null
                || offer.getPricingPhases().getPricingPhaseList().isEmpty()) return null;

        return offer.getPricingPhases().getPricingPhaseList().get(0).getFormattedPrice();
    }

    private String getSubscriptionOfferToken(ProductDetails details) {
        if (details == null || details.getSubscriptionOfferDetails() == null
                || details.getSubscriptionOfferDetails().isEmpty()) return null;

        return details.getSubscriptionOfferDetails().get(0).getOfferToken();
    }

    private void launchOneTimePurchase() {
        if (lifetimeProductDetails == null
                || lifetimeProductDetails.getOneTimePurchaseOfferDetailsList() == null
                || lifetimeProductDetails.getOneTimePurchaseOfferDetailsList().isEmpty()) {
            Toast.makeText(this, "Lifetime Premium is not available yet.", Toast.LENGTH_SHORT).show();
            return;
        }

        String offerToken = lifetimeProductDetails.getOneTimePurchaseOfferDetailsList()
                .get(0).getOfferToken();

        BillingFlowParams.ProductDetailsParams productParams =
                BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(lifetimeProductDetails)
                        .setOfferToken(offerToken)
                        .build();

        BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(productParams))
                .build();

        billingClient.launchBillingFlow(this, flowParams);
    }

    private void launchSubscriptionPurchase(ProductDetails details) {
        if (details == null) {
            Toast.makeText(this, "This subscription is not available yet.", Toast.LENGTH_SHORT).show();
            return;
        }

        String offerToken = getSubscriptionOfferToken(details);
        if (offerToken == null) {
            Toast.makeText(this, "Subscription offer is not available yet.", Toast.LENGTH_SHORT).show();
            return;
        }

        BillingFlowParams.ProductDetailsParams productParams =
                BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(details)
                        .setOfferToken(offerToken)
                        .build();

        BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(productParams))
                .build();

        billingClient.launchBillingFlow(this, flowParams);
    }

    private void setPremiumState(boolean active) {
        premiumActive = active;
        runOnUiThread(() -> {
            if (active) {
                if (adView != null) adView.setVisibility(View.GONE);
            } else {
                loadAdsIfNeeded();
            }

            if (webView != null) {
                webView.evaluateJavascript(
                        "window.AndroidPremiumState && window.AndroidPremiumState(" + active + ");",
                        null);
            }
        });
    }

    private void loadAdsIfNeeded() {
        if (premiumActive || adView == null) return;
        adView.setVisibility(View.VISIBLE);
        if (adView.getAdSize() != null) {
            adView.loadAd(new AdRequest.Builder().build());
        }
    }

    private class AndroidBillingBridge {
        @JavascriptInterface
        public void purchasePremium() {
            runOnUiThread(() -> launchPremiumPurchase());
        }

        @JavascriptInterface
        public boolean isPremium() {
            return premiumActive;
        }

        @JavascriptInterface
        public void restorePurchases() {
            runOnUiThread(() -> {
                queryExistingPurchases();
                Toast.makeText(MainActivity.this,
                        "Checking Google Play purchases...",
                        Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (billingClient != null && billingClient.isReady()) {
            queryExistingPurchases();
            queryAllPremiumProducts();
        }
        if (!premiumActive) loadAdsIfNeeded();
    }

    @Override
    protected void onDestroy() {
        if (adView != null) adView.destroy();
        if (billingClient != null) billingClient.endConnection();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
