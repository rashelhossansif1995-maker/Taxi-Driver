package com.taxidriver.apk;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.webkit.JavascriptInterface;
import android.graphics.pdf.PdfDocument;
import android.view.View;
import android.widget.FrameLayout;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.List;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout rootLayout;
    private File pendingPdfFile;
    private String pendingPdfFileName;
    private static final int REQUEST_CREATE_PDF = 4107;
    private static final String PREMIUM_PRODUCT_ID = "premium_remove_ads";
    private static final String PREFS_NAME = "taxi_driver_premium";
    private static final String PREF_PREMIUM = "premium_unlocked";
    private static final String ADMOB_BANNER_UNIT_ID = "ca-app-pub-2520301874823169/4467088492";
    private AdView adView;
    private BillingClient billingClient;
    private ProductDetails premiumProductDetails;
    private android.content.SharedPreferences premiumPrefs;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        rootLayout = new FrameLayout(this);
        webView = new WebView(this);
        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        rootLayout.addView(webView, webLp);

        premiumPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        setupAdView();
        setupBilling();
        setContentView(rootLayout);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new PdfBridge(), "AndroidPDF");
        webView.addJavascriptInterface(new BillingBridge(), "AndroidBilling");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void setupAdView() {
        adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId(ADMOB_BANNER_UNIT_ID);
        FrameLayout.LayoutParams adLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                dp(50)
        );
        adLp.gravity = android.view.Gravity.BOTTOM;
        rootLayout.addView(adView, adLp);

        if (isPremiumUnlocked()) {
            adView.setVisibility(View.GONE);
            updateWebViewBottomMargin(false);
        } else {
            adView.setVisibility(View.VISIBLE);
            updateWebViewBottomMargin(true);
            MobileAds.initialize(this, status -> loadBannerAd());
        }
    }

    private void loadBannerAd() {
        if (adView == null || isPremiumUnlocked()) return;
        runOnUiThread(() -> adView.loadAd(new AdRequest.Builder().build()));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private boolean isPremiumUnlocked() {
        return premiumPrefs != null && premiumPrefs.getBoolean(PREF_PREMIUM, false);
    }

    private void setPremiumUnlocked(boolean unlocked) {
        if (premiumPrefs != null) {
            premiumPrefs.edit().putBoolean(PREF_PREMIUM, unlocked).apply();
        }
        updateAdVisibility(unlocked);
        runOnUiThread(() -> {
            if (webView != null) {
                webView.evaluateJavascript(
                        "window.AndroidPremiumState && window.AndroidPremiumState(" + unlocked + ");",
                        null
                );
            }
        });
    }

    private void updateAdVisibility(boolean premium) {
        if (adView == null || rootLayout == null || webView == null) return;
        runOnUiThread(() -> {
            adView.setVisibility(premium ? View.GONE : View.VISIBLE);
            updateWebViewBottomMargin(!premium);
            if (premium) {
                adView.destroy();
            } else {
                loadBannerAd();
            }
        });
    }

    private void updateWebViewBottomMargin(boolean reserveAdSpace) {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) webView.getLayoutParams();
        lp.bottomMargin = reserveAdSpace ? dp(50) : 0;
        webView.setLayoutParams(lp);
    }

    private void setupBilling() {
        billingClient = BillingClient.newBuilder(this)
                .setListener(this::onPurchasesUpdated)
                .enablePendingPurchases(
                        PendingPurchasesParams.newBuilder()
                                .enableOneTimeProducts()
                                .build()
                )
                .enableAutoServiceReconnection()
                .build();
        billingClient.startConnection(new BillingClient.BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult billingResult) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    queryExistingPremiumPurchase();
                    queryPremiumProduct();
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // Automatic reconnection is enabled; no manual action is required here.
            }
        });
    }

    private void queryExistingPremiumPurchase() {
        if (billingClient == null || !billingClient.isReady()) return;
        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.INAPP)
                .build();
        billingClient.queryPurchasesAsync(params, (billingResult, purchases) -> {
            if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
            for (Purchase purchase : purchases) {
                if (purchase.getProducts().contains(PREMIUM_PRODUCT_ID)
                        && purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                    grantPremium(purchase);
                    return;
                }
            }
        });
    }

    private void queryPremiumProduct() {
        if (billingClient == null || !billingClient.isReady()) return;
        QueryProductDetailsParams.Product product = QueryProductDetailsParams.Product.newBuilder()
                .setProductId(PREMIUM_PRODUCT_ID)
                .setProductType(BillingClient.ProductType.INAPP)
                .build();
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(java.util.Collections.singletonList(product))
                .build();
        billingClient.queryProductDetailsAsync(params, (billingResult, result) -> {
            if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
            List<ProductDetails> products = result.getProductDetailsList();
            if (products != null && !products.isEmpty()) {
                premiumProductDetails = products.get(0);
            }
        });
    }

    private void purchasePremium() {
        if (isPremiumUnlocked()) {
            showBillingMessage("Premium is already active.");
            return;
        }
        if (billingClient == null || !billingClient.isReady()) {
            showBillingMessage("Google Play Billing is connecting. Please try again in a moment.");
            return;
        }
        if (premiumProductDetails == null) {
            queryPremiumProduct();
            showBillingMessage("Premium is not available yet. Make sure the one-time product is active in Google Play Console.");
            return;
        }

        List<ProductDetails.OneTimePurchaseOfferDetails> offers =
                premiumProductDetails.getOneTimePurchaseOfferDetailsList();
        if (offers == null || offers.isEmpty()) {
            showBillingMessage("No purchase offer is currently available for Premium.");
            return;
        }
        String offerToken = offers.get(0).getOfferToken();
        BillingFlowParams.ProductDetailsParams productDetailsParams =
                BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(premiumProductDetails)
                        .setOfferToken(offerToken)
                        .build();
        BillingFlowParams billingFlowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(java.util.Collections.singletonList(productDetailsParams))
                .build();
        billingClient.launchBillingFlow(this, billingFlowParams);
    }

    private void onPurchasesUpdated(BillingResult billingResult, List<Purchase> purchases) {
        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase purchase : purchases) {
                if (purchase.getProducts().contains(PREMIUM_PRODUCT_ID)) {
                    if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                        grantPremium(purchase);
                    } else if (purchase.getPurchaseState() == Purchase.PurchaseState.PENDING) {
                        showBillingMessage("Purchase is pending. Ads will be removed after Google Play confirms payment.");
                    }
                }
            }
        } else if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED) {
            showBillingMessage("Premium purchase could not be completed: " + billingResult.getDebugMessage());
        }
    }

    private void grantPremium(Purchase purchase) {
        setPremiumUnlocked(true);
        if (!purchase.isAcknowledged() && billingClient != null && billingClient.isReady()) {
            AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchase.getPurchaseToken())
                    .build();
            billingClient.acknowledgePurchase(params, billingResult -> {
                if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                    showBillingMessage("Premium was purchased, but Google Play acknowledgement is still pending.");
                }
            });
        }
        showBillingMessage("Premium activated. Ads have been removed.");
    }

    private void showBillingMessage(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    private class BillingBridge {
        @JavascriptInterface
        public boolean isPremium() {
            return isPremiumUnlocked();
        }

        @JavascriptInterface
        public void purchasePremium() {
            runOnUiThread(MainActivity.this::purchasePremium);
        }
    }

    private class PdfBridge {
        private String pendingTitle = "Taxi Driver PDF";
        private StringBuilder pendingHtml;

        @JavascriptInterface
        public synchronized boolean beginPdf(String title) {
            pendingTitle = (title == null || title.trim().isEmpty()) ? "Taxi Driver PDF" : title.trim();
            pendingHtml = new StringBuilder();
            return true;
        }

        @JavascriptInterface
        public synchronized boolean appendPdfChunk(String chunk) {
            if (pendingHtml == null) pendingHtml = new StringBuilder();
            if (chunk != null) pendingHtml.append(chunk);
            return true;
        }

        @JavascriptInterface
        public synchronized void finishPdf() {
            final String html = pendingHtml == null ? "" : pendingHtml.toString();
            final String title = pendingTitle;
            pendingHtml = null;
            runOnUiThread(() -> {
                final WebView printWebView = new WebView(MainActivity.this);
                WebSettings s = printWebView.getSettings();
                s.setJavaScriptEnabled(true);
                s.setDomStorageEnabled(true);
                s.setAllowFileAccess(true);
                s.setAllowContentAccess(true);

                printWebView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                final int initialWidth = Math.round(595f * getResources().getDisplayMetrics().density);
                FrameLayout.LayoutParams printLp = new FrameLayout.LayoutParams(initialWidth, Math.round(842f * getResources().getDisplayMetrics().density));
                printLp.leftMargin = 0;
                printLp.topMargin = 0;
                rootLayout.addView(printWebView, 0, printLp);

                printWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            view.postVisualStateCallback(System.nanoTime(), new WebView.VisualStateCallback() {
                                @Override
                                public void onComplete(long requestId) {
                                    view.postDelayed(() -> attachAndRenderPdfWebView(printWebView, title), 300);
                                }
                            });
                        } else {
                            view.postDelayed(() -> attachAndRenderPdfWebView(printWebView, title), 1000);
                        }
                    }
                });

                printWebView.loadDataWithBaseURL(
                        "file:///android_asset/",
                        html,
                        "text/html",
                        "UTF-8",
                        null
                );
            });
        }
    }

    private void attachAndRenderPdfWebView(final WebView printWebView, final String title) {
        try {
            printWebView.post(() -> generatePdfDirectly(printWebView, title));
        } catch (Exception e) {
            e.printStackTrace();
            try { printWebView.destroy(); } catch (Exception ignored) {}
            Toast.makeText(MainActivity.this, "PDF could not be created", Toast.LENGTH_LONG).show();
        }
    }

    private void generatePdfDirectly(final WebView printWebView, final String title) {
        final String safeTitle = sanitizeFileName(
                (title == null || title.trim().isEmpty()) ? "Taxi Driver PDF" : title.trim()
        );

        try {
            final float density = getResources().getDisplayMetrics().density;
            final int pageWidth = 595;
            final int pageHeight = 842;
            final int webWidth = Math.round(pageWidth * density);

            printWebView.measure(
                    View.MeasureSpec.makeMeasureSpec(webWidth, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            );
            int measuredHeight = Math.max(1, printWebView.getMeasuredHeight());
            printWebView.layout(0, 0, webWidth, measuredHeight);
            printWebView.requestLayout();

            int contentHeightCss = printWebView.getContentHeight();
            if (contentHeightCss <= 0) contentHeightCss = printWebView.getMeasuredHeight();
            int contentHeightPx = Math.max(1, Math.round(contentHeightCss * printWebView.getScale()));

            final int pageHeightPx = Math.round(pageHeight * density);
            final int pageCount = Math.max(1, (int) Math.ceil(contentHeightPx / (double) pageHeightPx));
            final File tempFile = new File(getCacheDir(), safeTitle + ".pdf");

            PdfDocument document = new PdfDocument();
            try {
                for (int pageIndex = 0; pageIndex < pageCount; pageIndex++) {
                    PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(
                            pageWidth, pageHeight, pageIndex + 1
                    ).create();
                    PdfDocument.Page page = document.startPage(pageInfo);
                    android.graphics.Canvas canvas = page.getCanvas();
                    canvas.save();
                    canvas.scale(1f / density, 1f / density);
                    canvas.translate(0, -pageIndex * pageHeightPx);
                    printWebView.draw(canvas);
                    canvas.restore();
                    document.finishPage(page);
                }

                try (FileOutputStream out = new FileOutputStream(tempFile)) {
                    document.writeTo(out);
                }
            } finally {
                document.close();
            }

            savePdfWithChooser(tempFile, safeTitle + ".pdf");
            try { rootLayout.removeView(printWebView); } catch (Exception ignored) {}
            printWebView.destroy();
        } catch (Exception e) {
            e.printStackTrace();
            runOnUiThread(() -> Toast.makeText(
                    MainActivity.this,
                    "PDF could not be created",
                    Toast.LENGTH_LONG
            ).show());
            try { printWebView.destroy(); } catch (Exception ignored) {}
        }
    }

    private void savePdfWithChooser(File source, String fileName) {
        try {
            pendingPdfFile = source;
            pendingPdfFileName = fileName;

            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/pdf");
            intent.putExtra(Intent.EXTRA_TITLE, fileName);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, REQUEST_CREATE_PDF);
        } catch (Exception e) {
            e.printStackTrace();
            saveToDownloads(source, fileName);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CREATE_PDF) return;

        File source = pendingPdfFile;
        pendingPdfFile = null;
        pendingPdfFileName = null;

        if (source == null) return;

        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            source.delete();
            Toast.makeText(this, "PDF save cancelled", Toast.LENGTH_SHORT).show();
            return;
        }

        Uri outputUri = data.getData();
        boolean success = false;
        try {
            try {
                getContentResolver().takePersistableUriPermission(
                        outputUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                );
            } catch (Exception ignored) {}

            try (InputStream in = new FileInputStream(source);
                 OutputStream out = getContentResolver().openOutputStream(outputUri, "w")) {
                if (out == null) throw new IOException("Unable to open selected file");
                copy(in, out);
                success = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            source.delete();
        }

        Toast.makeText(this, success ? "PDF saved successfully" : "PDF could not be saved", Toast.LENGTH_LONG).show();
    }

    private void saveToDownloads(File source, String fileName) {
        boolean success = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                values.put(MediaStore.Downloads.IS_PENDING, 1);

                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IOException("Unable to create Downloads file");

                try (InputStream in = new FileInputStream(source);
                     OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Unable to open Downloads output");
                    copy(in, out);
                }

                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
                success = true;
            } else {
                File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloads.exists() && !downloads.mkdirs()) throw new IOException("Cannot create Downloads");
                File target = new File(downloads, fileName);
                try (InputStream in = new FileInputStream(source);
                     OutputStream out = new FileOutputStream(target)) {
                    copy(in, out);
                }
                success = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            source.delete();
        }

        Toast.makeText(
                this,
                success ? "PDF saved to Downloads" : "PDF could not be saved",
                Toast.LENGTH_LONG
        ).show();
    }

    private void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[8192];
        int count;
        while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
        out.flush();
    }

    private void failPdf(File tempFile, WebView printWebView) {
        //noinspection ResultOfMethodCallIgnored
        tempFile.delete();
        runOnUiThread(() -> Toast.makeText(
                MainActivity.this,
                "PDF could not be created",
                Toast.LENGTH_LONG
        ).show());
        if (printWebView != null) printWebView.destroy();
    }

    private String sanitizeFileName(String name) {
        String cleaned = name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (cleaned.isEmpty()) cleaned = "Taxi Driver PDF";
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        return cleaned + "_" + stamp;
    }

    @Override
    protected void onDestroy() {
        if (adView != null) {
            adView.destroy();
            adView = null;
        }
        if (billingClient != null) {
            billingClient.endConnection();
            billingClient = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
