# Taxi Driver 1.1.1 — Final Save + Month History Fix

Version Code: 111
Version Name: 1.1.1
Target SDK: 36

Included fixes:
- Overpayment section retained and included in backup/restore data.
- Export Backup uses the native Android save-file dialog when available.
- Restore Backup uses the Android WebView file picker.
- Added a visible Choose File button for Restore Backup.
- Removed all literal "Financial Loan" wording from the HTML UI/report layer.
- Native MainActivity backup bridge remains enabled.


1.1.1 fixes:
- Save Income Entry immediately navigates to Dashboard without requiring app restart.
- Dashboard/History refresh immediately after saving.
- Older month records are preserved; changing month does not delete or replace previous records.
- Income entries are backed up internally before replacement to protect historical records.
