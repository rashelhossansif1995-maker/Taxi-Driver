# Taxi Driver 1.1.2 — Premium Popup HTML Integration

Version Code: 112
Version Name: 1.1.2
Target SDK: 36

Included fixes:
- Overpayment section retained and included in backup/restore data.
- Export Backup uses the native Android save-file dialog when available.
- Restore Backup uses the Android WebView file picker.
- Added a visible Choose File button for Restore Backup.
- Removed all literal "Financial Loan" wording from the HTML UI/report layer.
- Native MainActivity backup bridge remains enabled.


1.1.1 fixes:
- Save Income Entry immediately navigates to Dashboard without requiring app restart.
- Dashboard/History refresh immediately after saving.
- Older month records are preserved; changing month does not delete or replace previous records.
- Income entries are backed up internally before replacement to protect historical records.


1.1.1 MONTH FIX: Dashboard monthly cards use the current month when it has records; if the new month has no records yet, they continue showing the most recent month with saved records. History retains all months. Save navigates to Dashboard immediately after a successful save.


1.1.2 integration note:
- Replaced app/src/main/assets/index.html with the supplied Taxi-Driver-Premium-Popups.html, preserving the existing Android WebView entry path and native Java bridges.
- Premium popup markup was placed inside the HTML document body.
- Before Play Store release, verify the current production versionCode in Play Console and use a higher code if it is already 112 or greater.
- This source archive is not a signed AAB; build and sign it using the existing app signing/upload credentials.
