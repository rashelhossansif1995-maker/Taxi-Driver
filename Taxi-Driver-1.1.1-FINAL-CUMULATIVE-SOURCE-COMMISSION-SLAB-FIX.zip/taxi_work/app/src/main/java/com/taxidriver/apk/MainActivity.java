package com.taxidriver.apk;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {
    // Google Play product IDs configured in Play Console.
    private static final String LIFETIME_PRODUCT_ID = "taxi_driver_premium";
    private static final String MONTHLY_PRODUCT_ID = "taxi_driver_premium_monthly";
    private static final String YEARLY_PRODUCT_ID = "taxi_driver_premium_yearly";

    // Google test banner ID already present in the project.
    private static final String TEST_BANNER_AD_UNIT_ID = "ca-app-pub-2119693628616724/6269224943";

    private WebView webView;
    private WebView pdfPrintWebView;
    private AdView adView;
    private BillingClient billingClient;

    private ProductDetails lifetimeProductDetails;
    private ProductDetails monthlyProductDetails;
    private ProductDetails yearlyProductDetails;
    private boolean premiumActive = false;

    private static final int REQUEST_BACKUP_CREATE = 7001;
    private static final int REQUEST_BACKUP_OPEN = 7002;
    private String pendingBackupJson;
    private ValueCallback<Uri[]> pendingFileChooser;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        adView = new AdView(this);
        adView.setAdUnitId(TEST_BANNER_AD_UNIT_ID);
        adView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, 360));
        FrameLayout.LayoutParams adParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        adParams.gravity = android.view.Gravity.BOTTOM;
        root.addView(adView, adParams);
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback,
                                              FileChooserParams fileChooserParams) {
                if (pendingFileChooser != null) {
                    pendingFileChooser.onReceiveValue(null);
                }
                pendingFileChooser = filePathCallback;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES,
                            new String[]{"application/json", "text/plain", "*/*"});
                    startActivityForResult(intent, REQUEST_BACKUP_OPEN);
                    return true;
                } catch (Exception e) {
                    pendingFileChooser = null;
                    filePathCallback.onReceiveValue(null);
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new AndroidBackupBridge(), "AndroidBackup");
        webView.addJavascriptInterface(new AndroidPDFBridge(), "AndroidPDF");
        webView.addJavascriptInterface(new AndroidBillingBridge(), "AndroidBilling");
        webView.loadUrl("file:///android_asset/index.html");

        MobileAds.initialize(this, status -> {});
        loadAdsIfNeeded();
        setupBilling();
    }

    private void saveBackupFile(String json, String filename) {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, filename);
        pendingBackupJson = json;
        try {
            startActivityForResult(intent, REQUEST_BACKUP_CREATE);
        } catch (Exception e) {
            pendingBackupJson = null;
            Toast.makeText(this, "Unable to open file save dialog.", Toast.LENGTH_SHORT).show();
        }
    }

    private final StringBuilder pendingPdfHtml = new StringBuilder();

    private class AndroidPDFBridge {
        @JavascriptInterface
        public void beginPdf(String title) {
            synchronized (pendingPdfHtml) {
                pendingPdfHtml.setLength(0);
            }
        }

        @JavascriptInterface
        public void appendPdfChunk(String chunk) {
            if (chunk == null) return;
            synchronized (pendingPdfHtml) {
                pendingPdfHtml.append(chunk);
            }
        }

        @JavascriptInterface
        public void finishPdf() {
            final String html;
            synchronized (pendingPdfHtml) {
                html = pendingPdfHtml.toString();
                pendingPdfHtml.setLength(0);
            }
            runOnUiThread(() -> printHtmlToPdf(html));
        }
    }

    private void printHtmlToPdf(String html) {
        if (html == null || html.trim().isEmpty()) {
            Toast.makeText(this, "Unable to create PDF.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            if (pdfPrintWebView != null) {
                try {
                    ((FrameLayout) webView.getParent()).removeView(pdfPrintWebView);
                } catch (Exception ignored) {}
                try { pdfPrintWebView.destroy(); } catch (Exception ignored) {}
                pdfPrintWebView = null;
            }

            pdfPrintWebView = new WebView(this);
            pdfPrintWebView.setVisibility(View.INVISIBLE);
            WebSettings ps = pdfPrintWebView.getSettings();
            ps.setJavaScriptEnabled(false);
            ps.setDomStorageEnabled(true);
            ps.setAllowFileAccess(true);
            ps.setAllowContentAccess(true);

            FrameLayout root = (FrameLayout) webView.getParent();
            root.addView(pdfPrintWebView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));

            final String printJobName = "Taxi Driver PDF";
            pdfPrintWebView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    view.postDelayed(() -> {
                        try {
                            PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                            if (printManager == null) throw new Exception("Print service unavailable");

                            PrintAttributes attributes = new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build();

                            printManager.print(
                                    printJobName,
                                    view.createPrintDocumentAdapter(printJobName),
                                    attributes);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this,
                                    "Unable to open PDF save screen.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }, 500);
                }
            });

            pdfPrintWebView.loadDataWithBaseURL(
                    "file:///android_asset/",
                    html,
                    "text/html",
                    "UTF-8",
                    null);
        } catch (Exception e) {
            Toast.makeText(this, "Unable to create PDF.", Toast.LENGTH_SHORT).show();
        }
    }

    private class AndroidBackupBridge {
        @JavascriptInterface
        public void saveBackup(String json, String filename) {
            runOnUiThread(() -> saveBackupFile(json, filename));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_BACKUP_CREATE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                Uri uri = data.getData();
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Output stream unavailable");
                    out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    Toast.makeText(this, "Backup exported successfully.", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Unable to export backup.", Toast.LENGTH_SHORT).show();
                }
            }
            pendingBackupJson = null;
            return;
        }

        if (requestCode == REQUEST_BACKUP_OPEN) {
            if (pendingFileChooser != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
                pendingFileChooser.onReceiveValue(result);
                pendingFileChooser = null;
            }
        }
    }

    private void setupBilling() {
        PendingPurchasesParams pendingParams = PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts()
                .build();

        billingClient = BillingClient.newBuilder(this)
                .setListener(this::onPurchasesUpdated)
                .enablePendingPurchases(pendingParams)
                .build();

        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(@NonNull BillingResult billingResult) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    queryExistingPurchases();
                    queryAllPremiumProducts();
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // A later user action will retry the connection.
            }
        });
    }

    private void queryAllPremiumProducts() {
        queryAllPremiumProducts(null);
    }

    private void queryAllPremiumProducts(Runnable onComplete) {
        if (billingClient == null || !billingClient.isReady()) {
            if (onComplete != null) runOnUiThread(onComplete);
            return;
        }

        final boolean[] lifetimeDone = {false};
        final boolean[] subscriptionsDone = {false};
        final boolean[] completed = {false};

        Runnable finish = () -> {
            if (!completed[0] && lifetimeDone[0] && subscriptionsDone[0]) {
                completed[0] = true;
                if (onComplete != null) runOnUiThread(onComplete);
            }
        };

        QueryProductDetailsParams inAppParams = QueryProductDetailsParams.newBuilder()
                .setProductList(Collections.singletonList(
                        QueryProductDetailsParams.Product.newBuilder()
                                .setProductId(LIFETIME_PRODUCT_ID)
                                .setProductType(BillingClient.ProductType.INAPP)
                                .build()))
                .build();

        billingClient.queryProductDetailsAsync(inAppParams, (result, detailsResult) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK
                    && detailsResult != null
                    && detailsResult.getProductDetailsList() != null
                    && !detailsResult.getProductDetailsList().isEmpty()) {
                lifetimeProductDetails = detailsResult.getProductDetailsList().get(0);
            }
            lifetimeDone[0] = true;
            finish.run();
        });

        List<QueryProductDetailsParams.Product> subscriptionProducts = new ArrayList<>();
        subscriptionProducts.add(QueryProductDetailsParams.Product.newBuilder()
                .setProductId(MONTHLY_PRODUCT_ID)
                .setProductType(BillingClient.ProductType.SUBS)
                .build());
        subscriptionProducts.add(QueryProductDetailsParams.Product.newBuilder()
                .setProductId(YEARLY_PRODUCT_ID)
                .setProductType(BillingClient.ProductType.SUBS)
                .build());

        QueryProductDetailsParams subsParams = QueryProductDetailsParams.newBuilder()
                .setProductList(subscriptionProducts)
                .build();

        billingClient.queryProductDetailsAsync(subsParams, (result, detailsResult) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK
                    || detailsResult == null
                    || detailsResult.getProductDetailsList() == null) {
                subscriptionsDone[0] = true;
                finish.run();
                return;
            }

            for (ProductDetails details : detailsResult.getProductDetailsList()) {
                if (MONTHLY_PRODUCT_ID.equals(details.getProductId())) {
                    monthlyProductDetails = details;
                } else if (YEARLY_PRODUCT_ID.equals(details.getProductId())) {
                    yearlyProductDetails = details;
                }
            }
            subscriptionsDone[0] = true;
            finish.run();
        });
    }

    private void queryExistingPurchases() {
        if (billingClient == null || !billingClient.isReady()) return;

        QueryPurchasesParams inAppParams = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.INAPP)
                .build();

        billingClient.queryPurchasesAsync(inAppParams, (billingResult, purchases) -> {
            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                for (Purchase purchase : purchases) {
                    if (purchase.getProducts().contains(LIFETIME_PRODUCT_ID)
                            && purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                        acknowledgeIfNeeded(purchase);
                        return;
                    }
                }
            }
            querySubscriptionPurchases();
        });
    }

    private void querySubscriptionPurchases() {
        if (billingClient == null || !billingClient.isReady()) return;

        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.SUBS)
                .build();

        billingClient.queryPurchasesAsync(params, (billingResult, purchases) -> {
            if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                setPremiumState(false);
                return;
            }

            boolean found = false;
            for (Purchase purchase : purchases) {
                boolean isOurSubscription =
                        purchase.getProducts().contains(MONTHLY_PRODUCT_ID)
                                || purchase.getProducts().contains(YEARLY_PRODUCT_ID);

                if (isOurSubscription
                        && purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                    found = true;
                    acknowledgeIfNeeded(purchase);
                    break;
                }
            }

            if (!found) setPremiumState(false);
        });
    }

    private void onPurchasesUpdated(BillingResult billingResult, List<Purchase> purchases) {
        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK
                && purchases != null) {
            for (Purchase purchase : purchases) {
                boolean isOurProduct =
                        purchase.getProducts().contains(LIFETIME_PRODUCT_ID)
                                || purchase.getProducts().contains(MONTHLY_PRODUCT_ID)
                                || purchase.getProducts().contains(YEARLY_PRODUCT_ID);

                if (isOurProduct
                        && purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                    acknowledgeIfNeeded(purchase);
                }
            }
        } else if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED) {
            Toast.makeText(this, "Premium purchase could not be completed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void acknowledgeIfNeeded(Purchase purchase) {
        if (purchase.isAcknowledged()) {
            setPremiumState(true);
            return;
        }

        AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder()
                .setPurchaseToken(purchase.getPurchaseToken())
                .build();

        billingClient.acknowledgePurchase(params, billingResult -> {
            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                setPremiumState(true);
            }
        });
    }

    private void launchPremiumPurchase() {
        if (billingClient == null) {
            setupBilling();
            Toast.makeText(this, "Connecting to Google Play...", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!billingClient.isReady()) {
            billingClient.startConnection(new BillingClientStateListener() {
                @Override
                public void onBillingSetupFinished(@NonNull BillingResult result) {
                    if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                        queryAllPremiumProducts(MainActivity.this::showPremiumPlans);
                        queryExistingPurchases();
                    }
                }

                @Override
                public void onBillingServiceDisconnected() {}
            });
            return;
        }

        if (premiumActive) return;

        queryAllPremiumProducts(this::showPremiumPlans);
    }

    private void showPremiumPlans() {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;

            final String lifetime = getOneTimePrice(lifetimeProductDetails);
            final String monthly = getSubscriptionPrice(monthlyProductDetails);
            final String yearly = getSubscriptionPrice(yearlyProductDetails);

            if (lifetime == null && monthly == null && yearly == null) {
                Toast.makeText(this,
                        "Premium plans are not available yet. Please try again.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);

            ScrollView scroll = new ScrollView(this);
            scroll.setFillViewport(true);
            scroll.setBackgroundColor(Color.TRANSPARENT);

            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(dp(18), dp(10), dp(18), dp(18));
            root.setBackground(round(Color.WHITE, 28, 0xFFE2E6EA));

            // Header
            LinearLayout header = new LinearLayout(this);
            header.setGravity(Gravity.CENTER_VERTICAL);
            header.setPadding(0, 0, 0, dp(6));

            TextView back = new TextView(this);
            back.setText("‹");
            back.setTextColor(Color.BLACK);
            back.setTextSize(42);
            back.setGravity(Gravity.CENTER);
            back.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
            back.setOnClickListener(v -> dialog.dismiss());
            header.addView(back, new LinearLayout.LayoutParams(dp(48), dp(52)));

            TextView title = new TextView(this);
            title.setText("PREMIUM");
            title.setTextColor(Color.rgb(18, 25, 32));
            title.setTextSize(25);
            title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            title.setGravity(Gravity.CENTER);
            header.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1f));

            // Keep the right side balanced with the back button.
            TextView spacer = new TextView(this);
            header.addView(spacer, new LinearLayout.LayoutParams(dp(48), dp(52)));
            root.addView(header);

            ImageView logo = new ImageView(this);
            logo.setImageResource(R.drawable.taxi_driver_premium_logo);
            logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            logo.setAdjustViewBounds(true);
            LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(150), dp(150));
            logoLp.gravity = Gravity.CENTER_HORIZONTAL;
            logoLp.topMargin = dp(4);
            logoLp.bottomMargin = dp(14);
            root.addView(logo, logoLp);

            // Four icon-only benefits — no promotional text.
            LinearLayout benefits = new LinearLayout(this);
            benefits.setGravity(Gravity.CENTER);
            benefits.setPadding(dp(4), dp(4), dp(4), dp(14));
            String[] icons = {"♛", "🚫", "🌐", "⚡"};
            int[] iconColors = {0xFFFFD84D, 0xFFFFE8E8, 0xFFE1F0FF, 0xFFE4F8E9};
            for (int i = 0; i < icons.length; i++) {
                TextView icon = new TextView(this);
                icon.setText(icons[i]);
                icon.setTextSize(i == 0 ? 30 : 26);
                icon.setGravity(Gravity.CENTER);
                icon.setTextColor(i == 1 ? 0xFFE00000 : Color.BLACK);
                icon.setBackground(round(iconColors[i], 48, 0x00000000));
                LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(58), dp(58));
                ilp.gravity = Gravity.CENTER_VERTICAL;
                ilp.leftMargin = dp(5);
                ilp.rightMargin = dp(5);
                benefits.addView(icon, ilp);
            }
            root.addView(benefits);

            final LinearLayout plans = new LinearLayout(this);
            plans.setOrientation(LinearLayout.VERTICAL);
            root.addView(plans);

            final int[] selected = {lifetime != null ? 0 : (monthly != null ? 1 : 2)};
            final ArrayList<LinearLayout> planViews = new ArrayList<>();
            final ArrayList<RadioButton> radios = new ArrayList<>();

            addPremiumPlan(plans, planViews, radios, 0, "LIFETIME", lifetime, selected, dialog);
            addPremiumPlan(plans, planViews, radios, 1, "MONTHLY", monthly, selected, dialog);
            addPremiumPlan(plans, planViews, radios, 2, "YEARLY", yearly, selected, dialog);

            Button buy = new Button(this);
            buy.setText("GET PREMIUM");
            buy.setTextSize(17);
            buy.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            buy.setTextColor(Color.BLACK);
            buy.setAllCaps(false);
            buy.setBackground(round(0xFFFFC400, 22, 0x00FFFFFF));
            buy.setMinHeight(dp(56));
            buy.setPadding(dp(12), 0, dp(12), 0);
            LinearLayout.LayoutParams buyLp = new LinearLayout.LayoutParams(-1, dp(56));
            buyLp.topMargin = dp(14);
            root.addView(buy, buyLp);

            Button cancel = new Button(this);
            cancel.setText("CANCEL");
            cancel.setTextSize(16);
            cancel.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            cancel.setTextColor(Color.rgb(20, 28, 36));
            cancel.setAllCaps(false);
            cancel.setBackground(round(0xFFF1F3F5, 22, 0xFFD9DEE3));
            cancel.setMinHeight(dp(52));
            LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(-1, dp(52));
            cancelLp.topMargin = dp(10);
            root.addView(cancel, cancelLp);

            buy.setOnClickListener(v -> {
                int choice = selected[0];
                if (choice == 0) launchOneTimePurchase();
                else if (choice == 1) launchSubscriptionPurchase(monthlyProductDetails);
                else launchSubscriptionPurchase(yearlyProductDetails);
                dialog.dismiss();
            });
            cancel.setOnClickListener(v -> dialog.dismiss());

            scroll.addView(root);
            dialog.setContentView(scroll);
            android.view.Window w = dialog.getWindow();
            if (w != null) {
                w.setBackgroundDrawableResource(android.R.color.transparent);
                w.setDimAmount(0.38f);
                w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            }
            dialog.setOnShowListener(d -> {
                android.view.Window ww = dialog.getWindow();
                if (ww != null) {
                    ww.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.94f),
                            (int)(getResources().getDisplayMetrics().heightPixels * 0.88f));
                }
            });
            dialog.show();
            if (dialog.getWindow() != null) {
                dialog.getWindow().setLayout(
                        (int)(getResources().getDisplayMetrics().widthPixels * 0.94f),
                        (int)(getResources().getDisplayMetrics().heightPixels * 0.88f));
            }
        });
    }

    private void addPremiumPlan(LinearLayout parent, ArrayList<LinearLayout> planViews,
                                ArrayList<RadioButton> radios, int choice, String name,
                                String price, int[] selected, Dialog dialog) {
        if (price == null) return;

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(10), dp(8), dp(10), dp(8));
        card.setBackground(round(0xFFFFFFFF, 20, 0xFFDDE2E7));

        RadioButton radio = new RadioButton(this);
        radio.setButtonTintList(new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{0xFFFFB900, 0xFF707982}));
        radio.setChecked(selected[0] == choice);
        radio.setClickable(false);
        radio.setFocusable(false);
        card.addView(radio, new LinearLayout.LayoutParams(dp(48), dp(52)));
        radios.add(radio);

        TextView nameView = new TextView(this);
        nameView.setText(name);
        nameView.setTextColor(Color.rgb(18, 25, 32));
        nameView.setTextSize(18);
        nameView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0, dp(52), 1f);
        card.addView(nameView, nlp);

        TextView priceView = new TextView(this);
        priceView.setText(price);
        priceView.setTextColor(Color.rgb(18, 25, 32));
        priceView.setTextSize(17);
        priceView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        priceView.setGravity(Gravity.CENTER);
        priceView.setBackground(round(selected[0] == choice ? 0xFFFFC400 : 0xFFF0F2F4, 16, 0x00000000));
        card.addView(priceView, new LinearLayout.LayoutParams(dp(118), dp(48)));

        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, dp(72));
        clp.topMargin = dp(7);
        parent.addView(card, clp);
        planViews.add(card);

        View.OnClickListener click = v -> {
            selected[0] = choice;
            for (int i = 0; i < radios.size(); i++) {
                // Radio buttons are stored only for currently added plans; map selection by card order.
                radios.get(i).setChecked(i == planViews.indexOf(card));
            }
            for (int i = 0; i < planViews.size(); i++) {
                LinearLayout c = planViews.get(i);
                TextView pv = (TextView)c.getChildAt(2);
                boolean active = (i == planViews.indexOf(card));
                c.setBackground(round(active ? 0xFFFFFBEB : 0xFFFFFFFF, 20, active ? 0xFFFFC400 : 0xFFDDE2E7));
                pv.setBackground(round(active ? 0xFFFFC400 : 0xFFF0F2F4, 16, 0x00000000));
            }
        };
        card.setOnClickListener(click);
        radio.setOnClickListener(click);
        priceView.setOnClickListener(click);
        nameView.setOnClickListener(click);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable round(int fill, int radiusDp, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if ((stroke >>> 24) != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private String getOneTimePrice(ProductDetails details) {
        if (details == null || details.getOneTimePurchaseOfferDetailsList() == null
                || details.getOneTimePurchaseOfferDetailsList().isEmpty()) return null;
        return details.getOneTimePurchaseOfferDetailsList().get(0).getFormattedPrice();
    }

    private String getSubscriptionPrice(ProductDetails details) {
        if (details == null || details.getSubscriptionOfferDetails() == null
                || details.getSubscriptionOfferDetails().isEmpty()) return null;

        ProductDetails.SubscriptionOfferDetails offer =
                details.getSubscriptionOfferDetails().get(0);

        if (offer.getPricingPhases() == null
                || offer.getPricingPhases().getPricingPhaseList().isEmpty()) return null;

        return offer.getPricingPhases().getPricingPhaseList().get(0).getFormattedPrice();
    }

    private String getSubscriptionOfferToken(ProductDetails details) {
        if (details == null || details.getSubscriptionOfferDetails() == null
                || details.getSubscriptionOfferDetails().isEmpty()) return null;

        return details.getSubscriptionOfferDetails().get(0).getOfferToken();
    }

    private void launchOneTimePurchase() {
        if (lifetimeProductDetails == null
                || lifetimeProductDetails.getOneTimePurchaseOfferDetailsList() == null
                || lifetimeProductDetails.getOneTimePurchaseOfferDetailsList().isEmpty()) {
            Toast.makeText(this, "Lifetime Premium is not available yet.", Toast.LENGTH_SHORT).show();
            return;
        }

        String offerToken = lifetimeProductDetails.getOneTimePurchaseOfferDetailsList()
                .get(0).getOfferToken();

        BillingFlowParams.ProductDetailsParams productParams =
                BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(lifetimeProductDetails)
                        .setOfferToken(offerToken)
                        .build();

        BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(productParams))
                .build();

        billingClient.launchBillingFlow(this, flowParams);
    }

    private void launchSubscriptionPurchase(ProductDetails details) {
        if (details == null) {
            Toast.makeText(this, "This subscription is not available yet.", Toast.LENGTH_SHORT).show();
            return;
        }

        String offerToken = getSubscriptionOfferToken(details);
        if (offerToken == null) {
            Toast.makeText(this, "Subscription offer is not available yet.", Toast.LENGTH_SHORT).show();
            return;
        }

        BillingFlowParams.ProductDetailsParams productParams =
                BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(details)
                        .setOfferToken(offerToken)
                        .build();

        BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(productParams))
                .build();

        billingClient.launchBillingFlow(this, flowParams);
    }

    private void setPremiumState(boolean active) {
        premiumActive = active;
        runOnUiThread(() -> {
            if (active) {
                if (adView != null) adView.setVisibility(View.GONE);
            } else {
                loadAdsIfNeeded();
            }

            if (webView != null) {
                webView.evaluateJavascript(
                        "window.AndroidPremiumState && window.AndroidPremiumState(" + active + ");",
                        null);
            }
        });
    }

    private void loadAdsIfNeeded() {
        if (premiumActive || adView == null) return;
        adView.setVisibility(View.VISIBLE);
        if (adView.getAdSize() != null) {
            adView.loadAd(new AdRequest.Builder().build());
        }
    }

    private class AndroidBillingBridge {
        @JavascriptInterface
        public void purchasePremium() {
            runOnUiThread(() -> launchPremiumPurchase());
        }

        @JavascriptInterface
        public boolean isPremium() {
            return premiumActive;
        }

        @JavascriptInterface
        public void restorePurchases() {
            runOnUiThread(() -> {
                queryExistingPurchases();
                Toast.makeText(MainActivity.this,
                        "Checking Google Play purchases...",
                        Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (billingClient != null && billingClient.isReady()) {
            queryExistingPurchases();
            queryAllPremiumProducts();
        }
        if (!premiumActive) loadAdsIfNeeded();
    }

    @Override
    protected void onDestroy() {
        if (adView != null) adView.destroy();
        if (billingClient != null) billingClient.endConnection();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
