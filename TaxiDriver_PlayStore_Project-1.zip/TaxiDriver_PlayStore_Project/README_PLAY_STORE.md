# Taxi Driver — Play Store Android Project

- Application ID / Namespace: com.taxidriver.apk
- Target SDK: 36
- Compile SDK: 36
- Version code: 1
- Version name: 1.0.0
- Web app source: app/src/main/assets/index.html

## Build AAB
1. Open this folder in Android Studio.
2. Let Gradle sync and install Android SDK Platform 36 if prompted.
3. Create/select a release keystore.
4. Build > Generate Signed Bundle / APK > Android App Bundle.
5. Choose release and sign the AAB.
6. Upload the signed .aab to Google Play Console.
