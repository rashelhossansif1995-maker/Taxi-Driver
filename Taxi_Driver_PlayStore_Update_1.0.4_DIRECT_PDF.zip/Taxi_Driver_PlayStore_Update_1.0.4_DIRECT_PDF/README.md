# Taxi Driver — Play Store Update 1.0.4

This project keeps the supplied Taxi Driver HTML as the app content and packages it as an Android App Bundle (AAB).

## Play Store identity
- Application ID: `com.taxidriver.apk`
- Target SDK: 36
- Version Name: `1.0.4`
- Version Code: `104`

## Important for Play Store update
The existing Play Store app must use the same application ID. The release AAB must also be signed with the correct upload key for the existing Play App Signing setup.

## GitHub Actions signing
Add these repository secrets before a release build:
- `KEYSTORE_BASE64`
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

The workflow expects the keystore to be base64 encoded.
