package com.taxidriver.apk;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new PdfBridge(), "AndroidPDF");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class PdfBridge {
        @JavascriptInterface
        public void savePdf(final String html, final String title) {
            runOnUiThread(() -> {
                final WebView printWebView = new WebView(MainActivity.this);
                WebSettings s = printWebView.getSettings();
                s.setJavaScriptEnabled(true);
                s.setDomStorageEnabled(true);
                s.setAllowFileAccess(true);
                s.setAllowContentAccess(true);

                printWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        view.postDelayed(() -> generatePdfDirectly(printWebView, title), 500);
                    }
                });

                printWebView.loadDataWithBaseURL(
                        "file:///android_asset/",
                        html,
                        "text/html",
                        "UTF-8",
                        null
                );
            });
        }
    }

    private void generatePdfDirectly(final WebView printWebView, final String title) {
        final String safeTitle = sanitizeFileName(
                (title == null || title.trim().isEmpty()) ? "Taxi Driver PDF" : title.trim()
        );
        final File tempFile = new File(getCacheDir(), safeTitle + "_" + System.currentTimeMillis() + ".pdf");

        try {
            final PrintDocumentAdapter adapter = printWebView.createPrintDocumentAdapter(safeTitle);
            PrintAttributes attributes = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("taxi_pdf", "PDF", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();

            adapter.onLayout(null, attributes, null, new PrintDocumentAdapter.LayoutResultCallback() {
                @Override
                public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                    if (info == null) {
                        failPdf(tempFile, printWebView);
                        return;
                    }
                    try {
                        ParcelFileDescriptor pfd = ParcelFileDescriptor.open(
                                tempFile,
                                ParcelFileDescriptor.MODE_CREATE |
                                        ParcelFileDescriptor.MODE_TRUNCATE |
                                        ParcelFileDescriptor.MODE_READ_WRITE
                        );
                        adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, pfd, new CancellationSignal(),
                                new PrintDocumentAdapter.WriteResultCallback() {
                                    @Override
                                    public void onWriteFinished(PageRange[] pages) {
                                        try { pfd.close(); } catch (Exception ignored) {}
                                        saveToDownloads(tempFile, safeTitle + ".pdf");
                                        printWebView.destroy();
                                    }

                                    @Override
                                    public void onWriteFailed(CharSequence error) {
                                        try { pfd.close(); } catch (Exception ignored) {}
                                        failPdf(tempFile, printWebView);
                                    }
                                });
                    } catch (Exception e) {
                        failPdf(tempFile, printWebView);
                    }
                }

                @Override
                public void onLayoutFailed(CharSequence error) {
                    failPdf(tempFile, printWebView);
                }
            }, null);
        } catch (Exception e) {
            failPdf(tempFile, printWebView);
        }
    }

    private void saveToDownloads(File source, String fileName) {
        boolean success = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                values.put(MediaStore.Downloads.IS_PENDING, 1);

                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IOException("Unable to create Downloads file");

                try (InputStream in = new FileInputStream(source);
                     OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Unable to open Downloads output");
                    copy(in, out);
                }

                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
                success = true;
            } else {
                File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloads.exists() && !downloads.mkdirs()) throw new IOException("Cannot create Downloads");
                File target = new File(downloads, fileName);
                try (InputStream in = new FileInputStream(source);
                     OutputStream out = new FileOutputStream(target)) {
                    copy(in, out);
                }
                success = true;
            }
        } catch (Exception e) {
            success = false;
        } finally {
            //noinspection ResultOfMethodCallIgnored
            source.delete();
        }

        final boolean saved = success;
        runOnUiThread(() -> Toast.makeText(
                MainActivity.this,
                saved ? "PDF saved to Downloads" : "PDF could not be saved",
                Toast.LENGTH_LONG
        ).show());
    }

    private void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[8192];
        int count;
        while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
        out.flush();
    }

    private void failPdf(File tempFile, WebView printWebView) {
        //noinspection ResultOfMethodCallIgnored
        tempFile.delete();
        runOnUiThread(() -> Toast.makeText(
                MainActivity.this,
                "PDF could not be created",
                Toast.LENGTH_LONG
        ).show());
        if (printWebView != null) printWebView.destroy();
    }

    private String sanitizeFileName(String name) {
        String cleaned = name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (cleaned.isEmpty()) cleaned = "Taxi Driver PDF";
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        return cleaned + "_" + stamp;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
